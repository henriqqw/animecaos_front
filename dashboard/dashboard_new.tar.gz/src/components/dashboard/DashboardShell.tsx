"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

import { formatInteger, formatPercent, humanizeDate } from "@/shared/format";

import type {
  ExplorerBreakdownItem,
  ExplorerEventItem,
  ExplorerResponse,
  ExplorerSeriesPoint
} from "./types";

type RangeOption = "7d" | "30d" | "90d";
type PrimaryTab = "pages" | "routes" | "hostnames";
type AcquisitionTab = "referrers" | "utm";
type DeviceTab = "devices" | "browsers";

const RANGE_LABELS: Record<RangeOption, string> = {
  "7d": "Last 7 Days",
  "30d": "Last 30 Days",
  "90d": "Last 90 Days"
};

async function fetchJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`Request failed (${response.status})`);
  }
  return (await response.json()) as T;
}

function chartValueFormatter(value: number): string {
  return formatInteger(Math.max(0, Math.round(value)));
}

function renderCompactRows(items: ExplorerBreakdownItem[], isPercent = true) {
  if (items.length === 0) {
    return <p className="panel-muted">No data yet.</p>;
  }

  return items.map((item) => (
    <div className="list-row" key={item.name}>
      <span className="list-label">{item.name}</span>
      <span className="list-value">{isPercent ? formatPercent(item.percent) : formatInteger(item.visitors)}</span>
    </div>
  ));
}

function renderEventRows(items: ExplorerEventItem[]) {
  if (items.length === 0) {
    return <p className="panel-muted">No events tracked yet.</p>;
  }

  return items.map((item) => (
    <div className="list-row two-values" key={item.eventName}>
      <span className="list-label code">{item.eventName}</span>
      <div className="list-values">
        <span>{formatInteger(item.visitors)} visitors</span>
        <span>{formatInteger(item.total)} total</span>
      </div>
    </div>
  ));
}

function renderPageRows(items: Array<{ path: string; views: number; uniqueVisitors: number }>) {
  if (items.length === 0) {
    return <p className="panel-muted">No routes yet.</p>;
  }

  return items.map((item) => (
    <div className="list-row two-values" key={item.path}>
      <span className="list-label code">{item.path}</span>
      <div className="list-values">
        <span>{formatInteger(item.uniqueVisitors)} visitors</span>
        <span>{formatInteger(item.views)} views</span>
      </div>
    </div>
  ));
}

function renderTopRows(items: Array<{ name: string; visitors: number }>) {
  if (items.length === 0) {
    return <p className="panel-muted">No sources detected.</p>;
  }

  return items.map((item) => (
    <div className="list-row" key={item.name}>
      <span className="list-label">{item.name}</span>
      <span className="list-value">{formatInteger(item.visitors)}</span>
    </div>
  ));
}

export function DashboardShell() {
  const [range, setRange] = useState<RangeOption>("7d");
  const [primaryTab, setPrimaryTab] = useState<PrimaryTab>("pages");
  const [acquisitionTab, setAcquisitionTab] = useState<AcquisitionTab>("referrers");
  const [deviceTab, setDeviceTab] = useState<DeviceTab>("devices");
  const [data, setData] = useState<ExplorerResponse["explorer"] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    const run = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const response = await fetchJson<ExplorerResponse>(
          `/api/v1/metrics/explorer?range=${range}&limit=8`
        );

        if (!cancelled) {
          setData(response.explorer);
        }
      } catch (requestError) {
        if (!cancelled) {
          setError(requestError instanceof Error ? requestError.message : "Failed to load dashboard.");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void run();
    return () => {
      cancelled = true;
    };
  }, [range]);

  const points: ExplorerSeriesPoint[] = data?.points ?? [];

  const primaryRows = useMemo(() => {
    if (!data) {
      return [];
    }

    if (primaryTab === "routes") {
      return renderPageRows(data.routes);
    }

    if (primaryTab === "hostnames") {
      return renderCompactRows(data.hostnames, false);
    }

    return renderPageRows(data.pages);
  }, [data, primaryTab]);

  const acquisitionRows = useMemo(() => {
    if (!data) {
      return [];
    }

    if (acquisitionTab === "utm") {
      return renderTopRows(data.utmParameters);
    }

    return renderTopRows(data.referrers);
  }, [acquisitionTab, data]);

  return (
    <div className="vercel-shell">
      <header className="topbar glass">
        <div className="project-pill">
          <span className="dot" />
          <span>animecaos.vercel.app</span>
          <span className="online">0 online</span>
        </div>

        <div className="toolbar">
          <button className="ghost-btn" type="button">Production</button>
          <div className="segmented" role="tablist" aria-label="Time range">
            {(Object.keys(RANGE_LABELS) as RangeOption[]).map((option) => (
              <button
                key={option}
                type="button"
                className={`segment-btn ${range === option ? "active" : ""}`}
                onClick={() => setRange(option)}
              >
                {RANGE_LABELS[option]}
              </button>
            ))}
          </div>
        </div>
      </header>

      {data?.isSynthetic ? (
        <div className="synthetic-banner glass">No live events found in this range. Showing generated analytics preview.</div>
      ) : null}

      {error ? <div className="synthetic-banner glass error">{error}</div> : null}

      <section className="kpi-grid glass">
        <article className="kpi-item">
          <p>Visitors</p>
          <strong>{isLoading ? "..." : formatInteger(data?.visitors ?? 0)}</strong>
        </article>
        <article className="kpi-item">
          <p>Page Views</p>
          <strong>{isLoading ? "..." : formatInteger(data?.pageViews ?? 0)}</strong>
        </article>
        <article className="kpi-item">
          <p>Bounce Rate</p>
          <strong>{isLoading ? "..." : formatPercent(data?.bounceRate ?? 0)}</strong>
        </article>
      </section>

      <section className="chart-card glass">
        <div className="panel-title-row">
          <h2>Traffic</h2>
          <span>{RANGE_LABELS[range]}</span>
        </div>
        <div className="chart-wrap">
          {isLoading ? (
            <p className="panel-muted">Loading chart...</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={points}>
                <defs>
                  <linearGradient id="pvGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="rgba(30, 141, 255, 0.42)" />
                    <stop offset="100%" stopColor="rgba(30, 141, 255, 0.03)" />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                <XAxis
                  dataKey="date"
                  tickFormatter={humanizeDate}
                  stroke="rgba(255,255,255,0.45)"
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="rgba(255,255,255,0.45)"
                  tickFormatter={chartValueFormatter}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  formatter={(value: number, name: string) => [formatInteger(value), name]}
                  labelFormatter={(label) => humanizeDate(String(label))}
                  contentStyle={{
                    background: "rgba(8,10,15,0.95)",
                    border: "1px solid rgba(255,255,255,0.12)",
                    borderRadius: "10px"
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="pageViews"
                  name="Page Views"
                  stroke="#1e8dff"
                  fill="url(#pvGradient)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>

      <section className="grid two">
        <article className="panel-card glass">
          <div className="panel-title-row">
            <div className="tabs">
              <button type="button" className={primaryTab === "pages" ? "active" : ""} onClick={() => setPrimaryTab("pages")}>Pages</button>
              <button type="button" className={primaryTab === "routes" ? "active" : ""} onClick={() => setPrimaryTab("routes")}>Routes</button>
              <button type="button" className={primaryTab === "hostnames" ? "active" : ""} onClick={() => setPrimaryTab("hostnames")}>Hostnames</button>
            </div>
          </div>
          <div className="list-wrap">{primaryRows}</div>
        </article>

        <article className="panel-card glass">
          <div className="panel-title-row">
            <div className="tabs">
              <button type="button" className={acquisitionTab === "referrers" ? "active" : ""} onClick={() => setAcquisitionTab("referrers")}>Referrers</button>
              <button type="button" className={acquisitionTab === "utm" ? "active" : ""} onClick={() => setAcquisitionTab("utm")}>UTM Parameters</button>
            </div>
          </div>
          <div className="list-wrap">{acquisitionRows}</div>
        </article>
      </section>

      <section className="grid three">
        <article className="panel-card glass">
          <div className="panel-title-row"><h3>Countries</h3></div>
          <div className="list-wrap">{renderCompactRows(data?.countries ?? [])}</div>
        </article>

        <article className="panel-card glass">
          <div className="panel-title-row">
            <div className="tabs">
              <button type="button" className={deviceTab === "devices" ? "active" : ""} onClick={() => setDeviceTab("devices")}>Devices</button>
              <button type="button" className={deviceTab === "browsers" ? "active" : ""} onClick={() => setDeviceTab("browsers")}>Browsers</button>
            </div>
          </div>
          <div className="list-wrap">
            {deviceTab === "devices"
              ? renderCompactRows(data?.devices ?? [])
              : renderCompactRows(data?.browsers ?? [])}
          </div>
        </article>

        <article className="panel-card glass">
          <div className="panel-title-row"><h3>Operating Systems</h3></div>
          <div className="list-wrap">{renderCompactRows(data?.operatingSystems ?? [])}</div>
        </article>
      </section>

      <section className="grid two">
        <article className="panel-card glass">
          <div className="panel-title-row"><h3>Events</h3></div>
          <div className="list-wrap">{renderEventRows(data?.events ?? [])}</div>
        </article>
      </section>
    </div>
  );
}
