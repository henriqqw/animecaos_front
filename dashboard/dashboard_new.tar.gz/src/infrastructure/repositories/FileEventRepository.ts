import type { EventRepository } from "@/domain/events/EventRepository";
import type {
  AnalyticsEvent,
  BreakdownMetric,
  DailyMetricPoint,
  DashboardOverview,
  EventMetric,
  ExplorerMetrics,
  ExplorerTimeseriesPoint,
  FunnelMetric,
  TimeRange,
  TopPageMetric,
  TopReferrerMetric
} from "@/domain/events/types";
import { EventFileStore } from "@/infrastructure/db/fileStore";
import { enumerateUtcDays } from "@/shared/timeRange";

function percentage(numerator: number, denominator: number): number {
  if (denominator <= 0) {
    return 0;
  }

  return Number(((numerator / denominator) * 100).toFixed(2));
}

function eventInRange(event: AnalyticsEvent, range: TimeRange): boolean {
  return event.occurredAt >= range.from && event.occurredAt <= range.to;
}

function dayKey(value: string): string {
  return value.slice(0, 10);
}

function parseHostname(input: string | null): string | null {
  if (!input) {
    return null;
  }

  try {
    const url = new URL(input);
    return url.hostname.toLowerCase();
  } catch {
    return null;
  }
}

function parsePathname(input: string | null): string {
  if (!input) {
    return "/";
  }

  if (input.startsWith("/")) {
    return input.split("?")[0] ?? "/";
  }

  try {
    return new URL(input).pathname || "/";
  } catch {
    return "/";
  }
}

function extractUtmTag(path: string | null): string | null {
  if (!path || !path.includes("utm_")) {
    return null;
  }

  const query = path.split("?")[1];
  if (!query) {
    return null;
  }

  const params = new URLSearchParams(query);
  const source = params.get("utm_source");
  const medium = params.get("utm_medium");
  const campaign = params.get("utm_campaign");

  const value = [source, medium, campaign].filter(Boolean).join(" / ");
  return value || null;
}

function inferBrowser(userAgent: string | null): string {
  if (!userAgent) {
    return "Unknown";
  }

  const ua = userAgent.toLowerCase();
  if (ua.includes("edg/")) {
    return "Edge";
  }
  if (ua.includes("opr/") || ua.includes("opera")) {
    return "Opera";
  }
  if (ua.includes("chrome/")) {
    return "Chrome";
  }
  if (ua.includes("firefox/")) {
    return "Firefox";
  }
  if (ua.includes("safari/") && !ua.includes("chrome/")) {
    return "Safari";
  }

  return "Unknown";
}

function inferOperatingSystem(userAgent: string | null): string {
  if (!userAgent) {
    return "Unknown";
  }

  const ua = userAgent.toLowerCase();
  if (ua.includes("windows")) {
    return "Windows";
  }
  if (ua.includes("android")) {
    return "Android";
  }
  if (ua.includes("iphone") || ua.includes("ipad") || ua.includes("ios")) {
    return "iOS";
  }
  if (ua.includes("mac os") || ua.includes("macintosh")) {
    return "Mac";
  }
  if (ua.includes("linux")) {
    return "GNU/Linux";
  }

  return "Unknown";
}

function countryCodeToName(code: string | null): string {
  if (!code) {
    return "Unknown";
  }

  const upper = code.toUpperCase();
  try {
    const display = new Intl.DisplayNames(["en"], { type: "region" });
    return display.of(upper) ?? upper;
  } catch {
    return upper;
  }
}

function toBreakdown(entries: Array<[string, Set<string>]>, totalVisitors: number): BreakdownMetric[] {
  return entries
    .map(([name, visitors]) => ({
      name,
      visitors: visitors.size,
      percent: percentage(visitors.size, totalVisitors)
    }))
    .sort((left, right) => right.visitors - left.visitors);
}

function toTopList(entries: Array<[string, Set<string>]>): TopReferrerMetric[] {
  return entries
    .map(([name, visitors]) => ({
      name,
      visitors: visitors.size
    }))
    .sort((left, right) => right.visitors - left.visitors);
}

function buildSyntheticExplorer(range: TimeRange, limit: number): ExplorerMetrics {
  const days = enumerateUtcDays(range);
  const points = days.map((date, index) => {
    const pattern = Math.max(0, Math.round((Math.sin(index / 1.8) + 1.3) * 3));
    return {
      date,
      visitors: pattern,
      pageViews: pattern + Math.round(pattern * 0.5)
    };
  });

  const visitors = points.reduce((sum, point) => sum + point.visitors, 0);
  const pageViews = points.reduce((sum, point) => sum + point.pageViews, 0);

  const fallbackPages: TopPageMetric[] = [
    { path: "/pt", views: Math.max(1, Math.round(pageViews * 0.42)), uniqueVisitors: 12 },
    { path: "/pt/download", views: Math.max(1, Math.round(pageViews * 0.24)), uniqueVisitors: 8 },
    { path: "/pt/how-to-use", views: Math.max(1, Math.round(pageViews * 0.16)), uniqueVisitors: 6 },
    { path: "/pt/about", views: Math.max(1, Math.round(pageViews * 0.1)), uniqueVisitors: 4 }
  ].slice(0, limit);

  return {
    visitors,
    pageViews,
    bounceRate: 48,
    points,
    pages: fallbackPages,
    routes: fallbackPages,
    hostnames: [{ name: "animecaos.vercel.app", visitors: 18, percent: 100 }],
    referrers: [
      { name: "reddit.com", visitors: 9 },
      { name: "google.com", visitors: 6 },
      { name: "github.com", visitors: 4 }
    ],
    utmParameters: [
      { name: "reddit / social / launch", visitors: 7 },
      { name: "google / organic / brand", visitors: 5 }
    ],
    countries: [
      { name: "Brazil", visitors: 15, percent: 83.33 },
      { name: "United States", visitors: 2, percent: 11.11 },
      { name: "Portugal", visitors: 1, percent: 5.56 }
    ],
    devices: [
      { name: "Mobile", visitors: 11, percent: 61.11 },
      { name: "Desktop", visitors: 7, percent: 38.89 }
    ],
    browsers: [
      { name: "Chrome", visitors: 10, percent: 55.56 },
      { name: "Firefox", visitors: 5, percent: 27.78 },
      { name: "Safari", visitors: 3, percent: 16.67 }
    ],
    operatingSystems: [
      { name: "Windows", visitors: 8, percent: 44.44 },
      { name: "Android", visitors: 6, percent: 33.33 },
      { name: "iOS", visitors: 4, percent: 22.22 }
    ],
    events: [
      { eventName: "page_view", visitors: 18, total: pageViews },
      { eventName: "download_click", visitors: 8, total: Math.max(4, Math.round(pageViews * 0.22)) }
    ],
    isSynthetic: true
  };
}

export class FileEventRepository implements EventRepository {
  private readonly store: EventFileStore;
  private cacheLoaded = false;
  private readonly events: AnalyticsEvent[] = [];
  private readonly eventIds = new Set<string>();

  public constructor() {
    this.store = new EventFileStore();
  }

  public insertEvent(event: AnalyticsEvent): boolean {
    this.loadCache();
    if (this.eventIds.has(event.eventId)) {
      return false;
    }

    this.store.append(event);
    this.events.push(event);
    this.eventIds.add(event.eventId);
    return true;
  }

  public getOverview(range: TimeRange): DashboardOverview {
    this.loadCache();
    const inRange = this.events.filter((event) => eventInRange(event, range));

    const uniqueVisitors = new Set(inRange.map((event) => event.visitorId)).size;
    const totalEvents = inRange.length;
    const pageViews = inRange.filter((event) => event.eventName === "page_view").length;
    const downloadClicks = inRange.filter((event) => event.eventName === "download_click").length;
    const installs = inRange.filter(
      (event) => event.eventName === "pwa_installed" || event.eventName === "first_open"
    ).length;

    return {
      uniqueVisitors,
      totalEvents,
      pageViews,
      downloadClicks,
      installs,
      clickThroughRate: percentage(downloadClicks, pageViews),
      installRateFromClicks: percentage(installs, downloadClicks)
    };
  }

  public getTimeseries(range: TimeRange): DailyMetricPoint[] {
    this.loadCache();
    const inRange = this.events.filter((event) => eventInRange(event, range));
    const grouped = new Map<
      string,
      {
        pageViews: number;
        downloadClicks: number;
        installs: number;
        visitors: Set<string>;
      }
    >();

    for (const event of inRange) {
      const key = dayKey(event.occurredAt);
      const current = grouped.get(key) ?? {
        pageViews: 0,
        downloadClicks: 0,
        installs: 0,
        visitors: new Set<string>()
      };

      current.visitors.add(event.visitorId);
      if (event.eventName === "page_view") {
        current.pageViews += 1;
      }
      if (event.eventName === "download_click") {
        current.downloadClicks += 1;
      }
      if (event.eventName === "pwa_installed" || event.eventName === "first_open") {
        current.installs += 1;
      }

      grouped.set(key, current);
    }

    return [...grouped.entries()]
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([date, values]) => {
        return {
          date,
          pageViews: values.pageViews,
          uniqueVisitors: values.visitors.size,
          downloadClicks: values.downloadClicks,
          installs: values.installs
        };
      });
  }

  public getFunnel(range: TimeRange): FunnelMetric[] {
    this.loadCache();
    const inRange = this.events.filter((event) => eventInRange(event, range));
    const visitVisitors = new Set(
      inRange.filter((event) => event.eventName === "page_view").map((event) => event.visitorId)
    );
    const clickVisitors = new Set(
      inRange
        .filter((event) => event.eventName === "download_click")
        .map((event) => event.visitorId)
    );
    const installVisitors = new Set(
      inRange
        .filter((event) => event.eventName === "pwa_installed" || event.eventName === "first_open")
        .map((event) => event.visitorId)
    );

    const visitCount = visitVisitors.size;
    const clickCount = clickVisitors.size;
    const installCount = installVisitors.size;

    return [
      {
        step: "visit",
        visitors: visitCount,
        conversionFromPreviousStep: 100
      },
      {
        step: "click",
        visitors: clickCount,
        conversionFromPreviousStep: percentage(clickCount, visitCount)
      },
      {
        step: "install",
        visitors: installCount,
        conversionFromPreviousStep: percentage(installCount, clickCount)
      }
    ];
  }

  public getTopPages(range: TimeRange, limit: number): TopPageMetric[] {
    this.loadCache();
    const pageViews = this.events.filter(
      (event) => event.eventName === "page_view" && eventInRange(event, range)
    );

    const grouped = new Map<string, { views: number; visitors: Set<string> }>();
    for (const event of pageViews) {
      const path = parsePathname(event.path);
      const current = grouped.get(path) ?? { views: 0, visitors: new Set<string>() };
      current.views += 1;
      current.visitors.add(event.visitorId);
      grouped.set(path, current);
    }

    return [...grouped.entries()]
      .map(([path, values]) => ({
        path,
        views: values.views,
        uniqueVisitors: values.visitors.size
      }))
      .sort((left, right) => right.views - left.views)
      .slice(0, limit);
  }

  public getExplorerMetrics(range: TimeRange, limit: number): ExplorerMetrics {
    this.loadCache();
    const inRange = this.events.filter((event) => eventInRange(event, range));

    if (inRange.length === 0) {
      return buildSyntheticExplorer(range, limit);
    }

    const pageViewEvents = inRange.filter((event) => event.eventName === "page_view");
    const visitors = new Set(inRange.map((event) => event.visitorId));

    const pageMap = new Map<string, { views: number; visitors: Set<string> }>();
    const routeMap = new Map<string, { views: number; visitors: Set<string> }>();
    const hostnameMap = new Map<string, Set<string>>();
    const referrerMap = new Map<string, Set<string>>();
    const utmMap = new Map<string, Set<string>>();
    const countryMap = new Map<string, Set<string>>();
    const deviceMap = new Map<string, Set<string>>();
    const browserMap = new Map<string, Set<string>>();
    const osMap = new Map<string, Set<string>>();
    const eventMap = new Map<string, { total: number; visitors: Set<string> }>();

    for (const event of inRange) {
      const eventCurrent = eventMap.get(event.eventName) ?? { total: 0, visitors: new Set<string>() };
      eventCurrent.total += 1;
      eventCurrent.visitors.add(event.visitorId);
      eventMap.set(event.eventName, eventCurrent);

      const country = countryCodeToName(event.country);
      const countrySet = countryMap.get(country) ?? new Set<string>();
      countrySet.add(event.visitorId);
      countryMap.set(country, countrySet);

      const device = event.deviceType === "unknown" ? "Unknown" : event.deviceType[0].toUpperCase() + event.deviceType.slice(1);
      const deviceSet = deviceMap.get(device) ?? new Set<string>();
      deviceSet.add(event.visitorId);
      deviceMap.set(device, deviceSet);

      const browser = inferBrowser(event.userAgent);
      const browserSet = browserMap.get(browser) ?? new Set<string>();
      browserSet.add(event.visitorId);
      browserMap.set(browser, browserSet);

      const operatingSystem = inferOperatingSystem(event.userAgent);
      const osSet = osMap.get(operatingSystem) ?? new Set<string>();
      osSet.add(event.visitorId);
      osMap.set(operatingSystem, osSet);

      const referrerHost = parseHostname(event.referrer) ?? "direct";
      const referrerSet = referrerMap.get(referrerHost) ?? new Set<string>();
      referrerSet.add(event.visitorId);
      referrerMap.set(referrerHost, referrerSet);

      const utmTag = extractUtmTag(event.path);
      if (utmTag) {
        const utmSet = utmMap.get(utmTag) ?? new Set<string>();
        utmSet.add(event.visitorId);
        utmMap.set(utmTag, utmSet);
      }

      const hostname = event.path?.startsWith("http") ? parseHostname(event.path) : "animecaos.vercel.app";
      const hostnameSet = hostnameMap.get(hostname ?? "animecaos.vercel.app") ?? new Set<string>();
      hostnameSet.add(event.visitorId);
      hostnameMap.set(hostname ?? "animecaos.vercel.app", hostnameSet);

      if (event.eventName === "page_view") {
        const cleanPath = parsePathname(event.path);

        const pageCurrent = pageMap.get(cleanPath) ?? { views: 0, visitors: new Set<string>() };
        pageCurrent.views += 1;
        pageCurrent.visitors.add(event.visitorId);
        pageMap.set(cleanPath, pageCurrent);

        const firstSegment = cleanPath.split("/").filter(Boolean)[0];
        const route = firstSegment ? `/${firstSegment}` : "/";
        const routeCurrent = routeMap.get(route) ?? { views: 0, visitors: new Set<string>() };
        routeCurrent.views += 1;
        routeCurrent.visitors.add(event.visitorId);
        routeMap.set(route, routeCurrent);
      }
    }

    const pageViews = pageViewEvents.length;
    const uniqueVisitors = visitors.size;

    const sessionsByVisitor = new Map<string, { pageViews: number; engaged: boolean }>();
    for (const event of inRange) {
      const session = sessionsByVisitor.get(event.visitorId) ?? { pageViews: 0, engaged: false };
      if (event.eventName === "page_view") {
        session.pageViews += 1;
      }
      if (event.eventName !== "page_view") {
        session.engaged = true;
      }
      sessionsByVisitor.set(event.visitorId, session);
    }

    const bouncedVisitors = [...sessionsByVisitor.values()].filter(
      (session) => session.pageViews <= 1 && !session.engaged
    ).length;

    const rawPoints = new Map<string, { visitors: Set<string>; pageViews: number }>();
    for (const event of inRange) {
      const key = dayKey(event.occurredAt);
      const current = rawPoints.get(key) ?? { visitors: new Set<string>(), pageViews: 0 };
      current.visitors.add(event.visitorId);
      if (event.eventName === "page_view") {
        current.pageViews += 1;
      }
      rawPoints.set(key, current);
    }

    const points: ExplorerTimeseriesPoint[] = enumerateUtcDays(range).map((date) => {
      const item = rawPoints.get(date);
      return {
        date,
        visitors: item?.visitors.size ?? 0,
        pageViews: item?.pageViews ?? 0
      };
    });

    const pages = [...pageMap.entries()]
      .map(([path, values]) => ({ path, views: values.views, uniqueVisitors: values.visitors.size }))
      .sort((left, right) => right.views - left.views)
      .slice(0, limit);

    const routes = [...routeMap.entries()]
      .map(([path, values]) => ({ path, views: values.views, uniqueVisitors: values.visitors.size }))
      .sort((left, right) => right.views - left.views)
      .slice(0, limit);

    const events: EventMetric[] = [...eventMap.entries()]
      .map(([eventName, values]) => ({
        eventName,
        visitors: values.visitors.size,
        total: values.total
      }))
      .sort((left, right) => right.total - left.total)
      .slice(0, limit);

    return {
      visitors: uniqueVisitors,
      pageViews,
      bounceRate: percentage(bouncedVisitors, Math.max(uniqueVisitors, 1)),
      points,
      pages,
      routes,
      hostnames: toBreakdown([...hostnameMap.entries()], Math.max(uniqueVisitors, 1)).slice(0, limit),
      referrers: toTopList([...referrerMap.entries()]).slice(0, limit),
      utmParameters: toTopList([...utmMap.entries()]).slice(0, limit),
      countries: toBreakdown([...countryMap.entries()], Math.max(uniqueVisitors, 1)).slice(0, limit),
      devices: toBreakdown([...deviceMap.entries()], Math.max(uniqueVisitors, 1)).slice(0, limit),
      browsers: toBreakdown([...browserMap.entries()], Math.max(uniqueVisitors, 1)).slice(0, limit),
      operatingSystems: toBreakdown([...osMap.entries()], Math.max(uniqueVisitors, 1)).slice(0, limit),
      events,
      isSynthetic: false
    };
  }

  private loadCache(): void {
    if (this.cacheLoaded) {
      return;
    }

    const events = this.store.readAll();
    for (const event of events) {
      if (!this.eventIds.has(event.eventId)) {
        this.eventIds.add(event.eventId);
        this.events.push(event);
      }
    }
    this.cacheLoaded = true;
  }
}
